#include <stdio.h>
#include <string.h>

#define P 5
#define R 3

static int avail[R] = {3, 3, 2};
static int maxm[P][R] = {
    {7, 5, 3}, {3, 2, 2}, {9, 0, 2}, {2, 2, 2}, {4, 3, 3}
};
static int alloc[P][R] = {
    {0, 1, 0}, {2, 0, 0}, {3, 0, 2}, {2, 1, 1}, {0, 0, 2}
};

static int is_safe(int seq[P]) {
    int work[R], finish[P] = {0}, count = 0;
    memcpy(work, avail, sizeof work);

    while (count < P) {
        int found = 0;
        for (int p = 0; p < P; ++p) {
            if (finish[p]) continue;

            int can_finish = 1;
            for (int r = 0; r < R; ++r) {
                int need = maxm[p][r] - alloc[p][r];
                if (need > work[r]) {
                    can_finish = 0;
                    break;
                }
            }

            if (can_finish) {
                for (int r = 0; r < R; ++r) work[r] += alloc[p][r];
                finish[p] = 1;
                seq[count++] = p;
                found = 1;
            }
        }
        if (!found) return 0;
    }
    return 1;
}

static void request_resources(int p, const int req[R]) {
    for (int r = 0; r < R; ++r) {
        if (req[r] > maxm[p][r] - alloc[p][r] || req[r] > avail[r]) {
            printf("P%d request: must wait (not available)\n", p);
            return;
        }
    }

    for (int r = 0; r < R; ++r) {
        avail[r] -= req[r];
        alloc[p][r] += req[r];
    }

    int seq[P];
    if (is_safe(seq)) {
        printf("P%d request: granted, safe sequence", p);
        for (int i = 0; i < P; ++i) printf(" P%d", seq[i]);
        putchar('\n');
    } else {
        for (int r = 0; r < R; ++r) {
            avail[r] += req[r];
            alloc[p][r] -= req[r];
        }
        printf("P%d request: denied (unsafe)\n", p);
    }
}

int main(void) {
    int seq[P];
    if (is_safe(seq)) {
        printf("initial state safe:");
        for (int i = 0; i < P; ++i) printf(" P%d", seq[i]);
        putchar('\n');
    } else {
        puts("initial state is unsafe");
        return 1;
    }

    request_resources(1, (int[R]){1, 0, 2});
    request_resources(4, (int[R]){3, 3, 0});
    request_resources(0, (int[R]){0, 2, 0});
    return 0;
}
